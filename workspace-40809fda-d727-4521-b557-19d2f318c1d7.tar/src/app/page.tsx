'use client'

import { useEffect, useState } from 'react'
import { initializeApp } from 'firebase/app'
import { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth'
import { getDatabase, ref, onValue, off } from 'firebase/database'
import { Loader2, User, MapPin, Activity, Download, Search, Filter, Moon, Sun, X } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import 'ol/ol.css'
import Map from 'ol/Map'
import View from 'ol/View'
import TileLayer from 'ol/layer/Tile'
import VectorLayer from 'ol/layer/Vector'
import VectorSource from 'ol/source/Vector'
import OSM from 'ol/source/OSM'
import { fromLonLat } from 'ol/proj'
import Point from 'ol/geom/Point'
import Feature from 'ol/Feature'
import { Circle as CircleStyle, Fill, Stroke, Style } from 'ol/style'
import { Overlay } from 'ol/Overlay'
import Chart from 'chart.js/auto'

// Firebase configuration - should be moved to environment variables in production
const firebaseConfig = {
  apiKey: "AIzaSyCdT2nWv0fF6jZmDfslIUvRKFun18rStWs",
  authDomain: "tracking-654e3.firebaseapp.com",
  databaseURL: "https://tracking-654e3-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "tracking-654e3",
  storageBucket: "tracking-654e3.firebasestorage.app",
  messagingSenderId: "61074342637",
  appId: "1:61074342637:web:ee566c965c595668b5c2e4",
  measurementId: "G-Q5ZXKE7PTL"
}

interface User {
  id: string
  name?: string
  email?: string
  photoURL?: string
  status: 'active' | 'inactive'
  location?: {
    lat: number
    lng: number
    timestamp: number
  }
}

interface LoadingState {
  isLoading: boolean
  error: string | null
  timeoutReached: boolean
}

export default function AdminDashboard() {
  const [loadingState, setLoadingState] = useState<LoadingState>({
    isLoading: true,
    error: null,
    timeoutReached: false
  })
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [users, setUsers] = useState<User[]>([])
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all')
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [map, setMap] = useState<Map | null>(null)
  const [statusChart, setStatusChart] = useState<Chart | null>(null)
  const [hourlyChart, setHourlyChart] = useState<Chart | null>(null)
  
  const { toast } = useToast()

  // Initialize Firebase with error handling
  useEffect(() => {
    let firebaseApp: any
    let auth: any
    let database: any
    
    const initializeFirebase = () => {
      try {
        firebaseApp = initializeApp(firebaseConfig)
        auth = getAuth(firebaseApp)
        database = getDatabase(firebaseApp)
        
        // Set up auth state listener
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
          if (user) {
            try {
              // Check if user is admin
              const adminRef = ref(database, `admins/${user.uid}`)
              onValue(adminRef, (snapshot) => {
                const isAdmin = snapshot.val()
                if (isAdmin === true) {
                  setCurrentUser(user)
                  loadUsersData(database)
                  setLoadingState({ isLoading: false, error: null, timeoutReached: false })
                } else {
                  toast({
                    title: "Akses Ditolak",
                    description: "Anda bukan admin",
                    variant: "destructive"
                  })
                  signOut(auth)
                  setLoadingState({ isLoading: false, error: "Akses ditolak", timeoutReached: false })
                }
              }, (error) => {
                console.error('Error checking admin status:', error)
                toast({
                  title: "Error",
                  description: "Gagal memeriksa status admin",
                  variant: "destructive"
                })
                signOut(auth)
                setLoadingState({ isLoading: false, error: error.message, timeoutReached: false })
              })
            } catch (error) {
              console.error('Error during admin check:', error)
              toast({
                title: "Error",
                description: "Terjadi kesalahan saat memeriksa status admin",
                variant: "destructive"
              })
              signOut(auth)
              setLoadingState({ isLoading: false, error: String(error), timeoutReached: false })
            }
          } else {
            setCurrentUser(null)
            setLoadingState({ isLoading: false, error: null, timeoutReached: false })
          }
        })

        return unsubscribe
      } catch (error) {
        console.error('Firebase initialization error:', error)
        setLoadingState({ 
          isLoading: false, 
          error: 'Gagal menginisialisasi Firebase. Periksa koneksi internet Anda.', 
          timeoutReached: false 
        })
        toast({
          title: "Error",
          description: "Gagal menginisialisasi Firebase",
          variant: "destructive"
        })
      }
    }

    initializeFirebase()

    // Set up timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      if (loadingState.isLoading) {
        setLoadingState(prev => ({ ...prev, timeoutReached: true, isLoading: false }))
        toast({
          title: "Timeout",
          description: "Loading terlalu lama. Silakan refresh halaman.",
          variant: "destructive"
        })
      }
    }, 15000) // 15 seconds timeout

    return () => {
      clearTimeout(timeoutId)
    }
  }, [])

  // Load users data
  const loadUsersData = (database: any) => {
    const usersRef = ref(database, 'users')
    const locationDataRef = ref(database, 'location-data')

    // Load users
    onValue(usersRef, (snapshot) => {
      const usersObj = snapshot.val()
      const usersList: User[] = []
      
      if (usersObj) {
        Object.keys(usersObj).forEach(userId => {
          const userData = usersObj[userId]
          usersList.push({
            id: userId,
            ...userData,
            status: 'inactive' // Default status
          })
        })
      }

      // Load location data and merge with users
      onValue(locationDataRef, (locationSnapshot) => {
        const locations = locationSnapshot.val() || {}
        const updatedUsers = usersList.map(user => {
          const location = locations[user.id]
          return {
            ...user,
            location: location ? {
              lat: location.lat,
              lng: location.lng,
              timestamp: location.timestamp
            } : undefined,
            status: location ? 'active' : 'inactive'
          }
        })

        setUsers(updatedUsers)
        setFilteredUsers(updatedUsers)
        updateStats(updatedUsers)
        updateCharts(updatedUsers)
        initializeMap(updatedUsers)
      })
    })
  }

  // Initialize map
  const initializeMap = (usersData: User[]) => {
    if (typeof window === 'undefined') return

    const mapElement = document.getElementById('map')
    if (!mapElement) return

    try {
      const vectorSource = new VectorSource()
      
      // Add user markers
      usersData.forEach(user => {
        if (user.location?.lat && user.location?.lng) {
          const feature = new Feature({
            geometry: new Point(fromLonLat([user.location.lng, user.location.lat])),
            userData: user
          })
          
          feature.setStyle(new Style({
            image: new CircleStyle({
              radius: 7,
              fill: new Fill({ color: '#3B82F6' }),
              stroke: new Stroke({ color: '#FFFFFF', width: 2 })
            })
          }))
          
          vectorSource.addFeature(feature)
        }
      })

      const vectorLayer = new VectorLayer({
        source: vectorSource
      })

      const newMap = new Map({
        target: 'map',
        layers: [
          new TileLayer({
            source: new OSM()
          }),
          vectorLayer
        ],
        view: new View({
          center: fromLonLat([106.8456, -6.2088]),
          zoom: 10
        })
      })

      setMap(newMap)
    } catch (error) {
      console.error('Map initialization error:', error)
      toast({
        title: "Error",
        description: "Gagal memuat peta",
        variant: "destructive"
      })
    }
  }

  // Update statistics
  const updateStats = (usersData: User[]) => {
    const totalUsers = usersData.length
    const activeUsers = usersData.filter(u => u.status === 'active').length
    const inactiveUsers = usersData.filter(u => u.status === 'inactive').length

    // Update DOM elements
    const totalUsersEl = document.getElementById('totalUsers')
    const activeUsersEl = document.getElementById('activeUsers')
    const inactiveUsersEl = document.getElementById('inactiveUsers')

    if (totalUsersEl) totalUsersEl.textContent = totalUsers.toString()
    if (activeUsersEl) activeUsersEl.textContent = activeUsers.toString()
    if (inactiveUsersEl) inactiveUsersEl.textContent = inactiveUsers.toString()
  }

  // Update charts
  const updateCharts = (usersData: User[]) => {
    const activeCount = usersData.filter(u => u.status === 'active').length
    const inactiveCount = usersData.filter(u => u.status === 'inactive').length

    // Status chart
    const statusChartCanvas = document.getElementById('statusChart') as HTMLCanvasElement
    if (statusChartCanvas) {
      if (statusChart) statusChart.destroy()
      
      const newStatusChart = new Chart(statusChartCanvas, {
        type: 'doughnut',
        data: {
          labels: ['Active', 'Inactive'],
          datasets: [{
            data: [activeCount, inactiveCount],
            backgroundColor: ['#10B981', '#EF4444'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      })
      setStatusChart(newStatusChart)
    }

    // Hourly activity chart
    const hourlyData = Array(24).fill(0)
    usersData.forEach(user => {
      if (user.location?.timestamp) {
        const hour = new Date(user.location.timestamp).getHours()
        hourlyData[hour]++
      }
    })

    const hourlyChartCanvas = document.getElementById('hourlyChart') as HTMLCanvasElement
    if (hourlyChartCanvas) {
      if (hourlyChart) hourlyChart.destroy()
      
      const newHourlyChart = new Chart(hourlyChartCanvas, {
        type: 'bar',
        data: {
          labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
          datasets: [{
            label: 'User Activity',
            data: hourlyData,
            backgroundColor: '#3B82F6',
            borderColor: '#2563EB',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                stepSize: 1
              }
            }
          }
        }
      })
      setHourlyChart(newHourlyChart)
    }
  }

  // Filter users
  useEffect(() => {
    const filtered = users.filter(user => {
      const matchesSearch = 
        (user.name?.toLowerCase().includes(searchTerm.toLowerCase()) || false) ||
        (user.email?.toLowerCase().includes(searchTerm.toLowerCase()) || false)
      const matchesStatus = statusFilter === 'all' || user.status === statusFilter
      
      return matchesSearch && matchesStatus
    })
    
    setFilteredUsers(filtered)
  }, [users, searchTerm, statusFilter])

  // Handle login
  const handleLogin = async () => {
    try {
      const auth = getAuth()
      const provider = new GoogleAuthProvider()
      await signInWithPopup(auth, provider)
    } catch (error) {
      console.error('Login error:', error)
      toast({
        title: "Login Gagal",
        description: "Terjadi kesalahan saat login",
        variant: "destructive"
      })
    }
  }

  // Handle logout
  const handleLogout = async () => {
    try {
      const auth = getAuth()
      await signOut(auth)
      toast({
        title: "Logout Berhasil",
        description: "Anda telah berhasil logout"
      })
    } catch (error) {
      console.error('Logout error:', error)
      toast({
        title: "Logout Gagal",
        description: "Terjadi kesalahan saat logout",
        variant: "destructive"
      })
    }
  }

  // Export to CSV
  const exportToCSV = () => {
    const csvContent = [
      ['Name', 'Email', 'Status', 'Latitude', 'Longitude', 'Last Update'],
      ...filteredUsers.map(user => [
        user.name || '',
        user.email || '',
        user.status,
        user.location?.lat || '',
        user.location?.lng || '',
        user.location?.timestamp ? new Date(user.location.timestamp).toLocaleString() : ''
      ])
    ].map(row => row.join(',')).join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'users.csv'
    a.click()
    URL.revokeObjectURL(url)
    
    toast({
      title: "Export Berhasil",
      description: "Data berhasil diexport ke CSV"
    })
  }

  // Toggle dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle('dark')
  }

  // Show loading screen
  if (loadingState.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-blue-500" />
          <p className="text-gray-600">Loading...</p>
          {loadingState.timeoutReached && (
            <p className="text-sm text-red-500 mt-2">
              Loading terlalu lama. Silakan refresh halaman.
            </p>
          )}
        </div>
      </div>
    )
  }

  // Show error screen
  if (loadingState.error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center max-w-md">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <h1 className="text-2xl font-bold mb-4">Terjadi Kesalahan</h1>
          <p className="text-gray-600 mb-6">{loadingState.error}</p>
          <Button onClick={() => window.location.reload()}>
            Refresh Halaman
          </Button>
        </div>
      </div>
    )
  }

  // Show login screen
  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Admin Dashboard</CardTitle>
            <p className="text-gray-600 text-center">Silakan login untuk melanjutkan</p>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={handleLogin} 
              className="w-full bg-red-500 hover:bg-red-600"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Login dengan Google
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Show dashboard
  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-100'}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="icon"
                onClick={toggleDarkMode}
              >
                {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              <div className="flex items-center space-x-2">
                {currentUser.photoURL ? (
                  <img 
                    src={currentUser.photoURL} 
                    alt="Profile" 
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <User className="w-8 h-8 rounded-full bg-gray-300 p-1" />
                )}
                <span className="text-gray-700 dark:text-gray-300">
                  {currentUser.displayName || 'Admin'}
                </span>
                <Button 
                  variant="outline" 
                  onClick={handleLogout}
                  className="ml-4"
                >
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600" id="totalUsers">
                {users.length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600" id="activeUsers">
                {users.filter(u => u.status === 'active').length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inactive Users</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600" id="inactiveUsers">
                {users.filter(u => u.status === 'inactive').length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Map and User Management */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Map */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                User Locations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div id="map" className="h-96 rounded-lg border"></div>
            </CardContent>
          </Card>

          {/* User Management */}
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={statusFilter} onValueChange={(value: any) => setStatusFilter(value)}>
                  <SelectTrigger className="w-full md:w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={exportToCSV} className="bg-green-500 hover:bg-green-600">
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              </div>
              
              <div className="overflow-x-auto max-h-96">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Last Update</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500">
                          No users found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredUsers.map((user) => (
                        <TableRow 
                          key={user.id} 
                          className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
                          onClick={() => setSelectedUser(user)}
                        >
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              {user.photoURL ? (
                                <img 
                                  src={user.photoURL} 
                                  alt={user.name} 
                                  className="w-8 h-8 rounded-full"
                                />
                              ) : (
                                <User className="w-8 h-8 rounded-full bg-gray-300 p-1" />
                              )}
                              <span className="font-medium">{user.name || 'Unknown'}</span>
                            </div>
                          </TableCell>
                          <TableCell>{user.email || 'N/A'}</TableCell>
                          <TableCell>
                            <Badge 
                              variant={user.status === 'active' ? 'default' : 'secondary'}
                              className={user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                            >
                              {user.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {user.location ? 
                              `${user.location.lat?.toFixed(4)}, ${user.location.lng?.toFixed(4)}` : 
                              'N/A'
                            }
                          </TableCell>
                          <TableCell>
                            {user.location?.timestamp ? 
                              new Date(user.location.timestamp).toLocaleString() : 
                              'Never'
                            }
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Activity Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Activity Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-medium mb-4">User Status Distribution</h3>
                <div className="h-80">
                  <canvas id="statusChart"></canvas>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-4">Hourly Activity</h3>
                <div className="h-80">
                  <canvas id="hourlyChart"></canvas>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* User Detail Modal */}
      <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                {selectedUser.photoURL ? (
                  <img 
                    src={selectedUser.photoURL} 
                    alt={selectedUser.name} 
                    className="w-16 h-16 rounded-full"
                  />
                ) : (
                  <User className="w-16 h-16 rounded-full bg-gray-300 p-3" />
                )}
                <div>
                  <h3 className="text-lg font-semibold">{selectedUser.name || 'Unknown'}</h3>
                  <p className="text-gray-600">{selectedUser.email || 'N/A'}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Status</label>
                  <p>
                    <Badge 
                      variant={selectedUser.status === 'active' ? 'default' : 'secondary'}
                      className={selectedUser.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                    >
                      {selectedUser.status}
                    </Badge>
                  </p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-500">Location</label>
                  <p className="text-sm">
                    {selectedUser.location ? 
                      `${selectedUser.location.lat?.toFixed(4)}, ${selectedUser.location.lng?.toFixed(4)}` : 
                      'N/A'
                    }
                  </p>
                </div>
                
                <div className="col-span-2">
                  <label className="text-sm font-medium text-gray-500">Last Update</label>
                  <p className="text-sm">
                    {selectedUser.location?.timestamp ? 
                      new Date(selectedUser.location.timestamp).toLocaleString() : 
                      'Never'
                    }
                  </p>
                </div>
              </div>
              
              <Button 
                onClick={() => setSelectedUser(null)} 
                className="w-full"
              >
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}